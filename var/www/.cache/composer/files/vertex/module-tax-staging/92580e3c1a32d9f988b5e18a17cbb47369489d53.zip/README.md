# Vertex Tax Staging

This module provides support for staging Commodity Codes on Products.

This module provides no extension points.  To stage commodity codes on products,
please use the existing Magento_CatalogStaging API points with the commodity
code extension attributes.
