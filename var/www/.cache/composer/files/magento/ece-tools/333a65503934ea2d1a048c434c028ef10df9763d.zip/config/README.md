# Configuring .XSD schema integration into PhpStorm

1. Open `Config -> Languages & Frameworks -> Schemas and DTDs`
2. Add new item pointing `urn:magento:ece-tools:config/scenario.xsd` to the correct file in ECE-Tools codebase
