
## v1.1.6

-  **magento/magento2-base** _(for Magento `2.3.7`)_-"MC-41887: Validation Messages - CustomerData messages not showing up": Fixed issue with don't visible messages for sites hosted on subdirectories due to cookie restriction
-  **magento/magento2-base** _(for Magento `2.4.3`)_-"Optimize QuoteIdToMaskedQuoteId model and fix infinite loop": Improve performance by using direct SQL queries

## v1.1.4

-  **magento2-base** _(for Magento `2.4.3`)_-"Added patch for the upgrade issue from 2.4.2 to 2.4.3": Fixes Upgrade Issue, While upgrade from Magento 2.4.2-p1 to Magento 2.4.3 for PayPal data patch
-  **magento2-base** _(for Magento `2.3.7`)_-"backport  #28137  to 2.3": Fixes issue with Varnish 6 when 503 error was returned and VCL error Too many restarts in logs

## v1.1.2

-  **magento2-base** _(for Magento `2.3.7`)_-"Optimize QuoteIdToMaskedQuoteId model": Improve performance by using direct SQL queries

