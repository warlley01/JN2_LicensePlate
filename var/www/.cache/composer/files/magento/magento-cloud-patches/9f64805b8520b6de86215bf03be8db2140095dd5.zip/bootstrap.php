<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
require __DIR__ . '/autoload.php';

use Magento\CloudPatches\App\Container;

return new Container(__DIR__, BP);
