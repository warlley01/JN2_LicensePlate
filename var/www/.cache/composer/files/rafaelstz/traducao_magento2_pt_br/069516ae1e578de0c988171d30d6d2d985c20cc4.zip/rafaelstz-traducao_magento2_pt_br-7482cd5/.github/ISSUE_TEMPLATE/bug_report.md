---
name: Bug
about: Reporte um bug para nos ajudar a melhorar a tradução
title: "[BUG]"
labels: bug
assignees: ''

---

**Printscreen (Opcional)**

**Descrição do bug**