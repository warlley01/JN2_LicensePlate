<?php

declare(strict_types=1);

namespace Laminas\Stdlib\Exception;

/**
 * Extension not loaded exception
 */
class ExtensionNotLoadedException extends RuntimeException
{
}
