<?php

namespace Laminas\EventManager\Exception;

/**
 * Invalid argument exception
 */
class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
