<?php

namespace Laminas\Uri\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
