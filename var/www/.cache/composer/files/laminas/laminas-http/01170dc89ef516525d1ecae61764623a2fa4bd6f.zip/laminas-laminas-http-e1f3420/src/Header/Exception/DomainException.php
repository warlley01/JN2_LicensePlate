<?php

namespace Laminas\Http\Header\Exception;

class DomainException extends \DomainException implements ExceptionInterface
{
}
