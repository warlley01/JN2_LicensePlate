<?php

/**
 * Legacy purposes only, to prevent code that references it from breaking.
 */

trigger_error('Polyfill autoload support (file library/Laminas/Session/compatibility/autoload.php) is no longer'
. ' necessary; please remove your require statement referencing this file', E_USER_DEPRECATED);
