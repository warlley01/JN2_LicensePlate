<?php

namespace Laminas\Loader\Exception;

require_once __DIR__ . '/DomainException.php';

/**
 * Plugin class loader exceptions
 */
class PluginLoaderException extends DomainException
{
}
