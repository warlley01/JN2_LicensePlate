# laminas-serializer

[![Build Status](https://github.com/laminas/laminas-serializer/workflows/Continuous%20Integration/badge.svg)](https://github.com/laminas/laminas-serializer/actions?query=workflow%3A"Continuous+Integration")

laminas-serializer provides an adapter-based interface for generating and
recovering from storable representations of PHP types.

- File issues at https://github.com/laminas/laminas-serializer/issues
- Documentation is at https://docs.laminas.dev/laminas-serializer/
