# laminas-soap

[![Build Status](https://github.com/laminas/laminas-soap/workflows/Continuous%20Integration/badge.svg)](https://github.com/laminas/laminas-soap/actions?query=workflow%3A"Continuous+Integration")

`Laminas\Soap` is a component to manage the [SOAP](http://en.wikipedia.org/wiki/SOAP)
protocol in order to design client or server PHP application.

- File issues at https://github.com/laminas/laminas-soap/issues
- Documentation is at https://docs.laminas.dev/laminas-soap/
