<?php

namespace Dotdigitalgroup\B2b\Setup;

interface SchemaInterface
{
    const EMAIL_B2B_QUOTE_TABLE = 'email_b2b_quote';
}
